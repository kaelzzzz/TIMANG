#pragma once

#define HTTP_SERVER "37.221.92.200"
#define HTTP_PORT 80

#define TFTP_SERVER "37.221.92.200"
